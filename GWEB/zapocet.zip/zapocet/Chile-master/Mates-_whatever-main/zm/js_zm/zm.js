// Inicializace mapy
var mapa = L.map('mapa').setView([-29.103246462503115, -70.62472188820367], 4); // [latitude, longitude], zoom level

// Přidání OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data © <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
    maxZoom: 19
}).addTo(mapa);

var data_lyr = L.featureGroup();

// Data pro více bodů
var locations = [
    { 
        name: "Hlavní město - Santiago de Chile", 
        coords: [-33.46179568838183, -70.65937105506048], 
        description: "Hlavní město Chile, známé svou kulturou a historií." 
    },
    { 
        name: "Poušť Atacama", 
        coords: [-23.86383347718813, -69.13262875737095], 
        description: "Jedna z nejsušších oblastí na světě s úžasnou krajinou." 
    },
    { 
        name: "Velikonoční ostrov", 
        coords: [-27.112858855445953, -109.35168002736042], 
        description: "Známý svými ikonickými sochami Moai." 
    },
    { 
        name: "El Tatio", 
        coords: [-22.33489979937848, -68.01296547509412], 
        description: "Gejzíry v nadmořské výšce přes 4 000 m." 
    }
];

// Přidání markerů na základě dat
locations.forEach(function(location) {
    var marker = L.marker(location.coords);
    var popupContent = `
        <b>${location.name}</b><br>
        GPS: ${location.coords[0].toFixed(5)}, ${location.coords[1].toFixed(5)}<br>
        ${location.description}
    `;
    marker.bindPopup(popupContent); // Popup s názvem, GPS a popisem
    marker.addTo(data_lyr);
});

data_lyr.addTo(mapa);
